from datetime import datetime
import pandas as pd
from pymongo import MongoClient


def crawl_to_mongo(data: list[dict]):
    """ crawl_data mongodb 적재"""

    # mongodb 접속정보 host 는 docker 컨테이너 이름으로 지정해야함.
    client = MongoClient("mongodb+srv://startup_proj_de_08:Team08!!@team08.mi7hgs1.mongodb.net/?retryWrites=true&w=majority")

    # db 이름
    db = client["ConnectsLab"]

    # 연결할 컬랙션 이름
    collection = db["insta_crawling"]

    # 적재
    collection.insert_many(data)

    # MongoDB 연결 종료
    client.close()

def morphs_to_mongo(data: list[dict]):
    """ morphs_data mongodb 적재"""

    # mongodb 접속정보 host 는 docker 컨테이너 이름으로 지정해야함.
    client = MongoClient(host="mongodb+srv://startup_proj_de_08:Team08!!@team08.mi7hgs1.mongodb.net/?retryWrites=true&w=majority")

    # db 이름
    db = client["ConnectsLab"]

    # 연결할 컬랙션 이름
    collection = db["insta_crawling_morphs"]

    # 적재
    collection.insert_many(data)

    # MongoDB 연결 종료
    client.close()

def crawl_to_mongo_daily(data: list[dict]):
    """ daily_data mongodb 적재"""

    # mongodb 접속정보 host 는 docker 컨테이너 이름으로 지정해야함.
    client = MongoClient("mongodb+srv://startup_proj_de_08:Team08!!@team08.mi7hgs1.mongodb.net/?retryWrites=true&w=majority")

    # db 이름
    db = client["ConnectsLab"]

    # 연결할 컬랙션 이름
    collection = db["insta_daily_data"]

    collection.delete_many({})

    # 적재
    collection.insert_many(data)

    # MongoDB 연결 종료
    client.close()

def pull_daily_mongo(data ):
    """daily로 크롤링한 데이터 불러오기 (return:Dataframe)"""

    # mongodb 접속정보 host 는 docker 컨테이너 이름으로 지정해야함.
    client = MongoClient(host="mongodb+srv://startup_proj_de_08:Team08!!@team08.mi7hgs1.mongodb.net/?retryWrites=true&w=majority")

    # db 이름
    db = client["ConnectsLab"]

    # 연결할 컬랙션 이름
    collection = db["insta_daily_data"]

    # 쿼리
    query = {}
    daily_data = collection.find(query)
    daily_data = pd.DataFrame(daily_data)
    return daily_data


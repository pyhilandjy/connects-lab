from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from services.instagram_job import get_instagram
from services.morphs_job import morphs


# Airflow DAG 설정
default_args = {
    "owner": "airflow",
    "depends_on_past": False,
    "start_date": datetime(2023, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=1),
}

get_instagram_info_dag = DAG(
    "get_instagram_info",
    default_args=default_args,
    description="daily clawl instagram_data",
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 11, 17),  # 현재 날짜로 변경
    catchup=False,  # 과거 데이터 캐치업 방지
)

morphs_dag = DAG(
    "morphs",
    default_args=default_args,
    description="morphs instagram data",
    schedule_interval=None,  # None으로 설정하여 수동으로 실행되어야 함
    start_date=datetime(2023, 11, 17),  # 현재 날짜로 변경
    catchup=False,  # 과거 데이터 캐치업 방지
)

get_instagram_info_operator = PythonOperator(
    task_id="get_instagram_info_task",
    python_callable=get_instagram,
    dag=get_instagram_info_dag,
)

morphs_operator = PythonOperator(
    task_id="morphs_task",
    python_callable=morphs,
    dag=morphs_dag,
)

# get_instagram_info DAG가 끝나면 morphs DAG를 트리거
trigger_morphs_dag = TriggerDagRunOperator(
    task_id="trigger_morphs_dag",
    trigger_dag_id="morphs",
    dag=get_instagram_info_dag,
)

# Task 간의 의존성 설정
get_instagram_info_operator >> trigger_morphs_dag
trigger_morphs_dag >> morphs_operator
